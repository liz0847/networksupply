        < script >
            function openForm(type)
        document.getElementById("popupOverlay").style.display = "block";
        document.getElementById("signForm").style.display = "none";
        document.getElementById("registerForm").style.display = "none";
        document.getElementById(type + "Form").style.display = "block";


        function closeAllForms()
        document.getElementById("popupOverlay").style.display = "none";
        document.getElementById("signForm").style.display = "none";
        document.getElementById("registerForm").style.display = "none";



        <
        /script>